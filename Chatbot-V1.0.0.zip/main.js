const _0x2dd508 = (function () {
    let _0x5ac763 = !![];
    return function (_0x347e03, _0x125e6c) {
        const _0xcd1fb4 = _0x5ac763 ? function () {
            if (_0x125e6c) {
                const _0x5bc7db = _0x125e6c['apply'](_0x347e03, arguments);
                _0x125e6c = null;
                return _0x5bc7db;
            }
        } : function () {
        };
        _0x5ac763 = ![];
        return _0xcd1fb4;
    };
}());
(function () {
    _0x2dd508(this, function () {
        const _0xa55858 = new RegExp('function\x20*\x5c(\x20*\x5c)');
        const _0x5c95c7 = new RegExp('\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i');
        const _0xb86f8c = _0x15fdd5('init');
        if (!_0xa55858['test'](_0xb86f8c + 'chain') || !_0x5c95c7['test'](_0xb86f8c + 'input')) {
            _0xb86f8c('0');
        } else {
            _0x15fdd5();
        }
    })();
}());
const _0x234ec1 = (function () {
    let _0xd39e8b = !![];
    return function (_0x512d62, _0x1dffca) {
        const _0x15cb3a = _0xd39e8b ? function () {
            if (_0x1dffca) {
                const _0x26e7e0 = _0x1dffca['apply'](_0x512d62, arguments);
                _0x1dffca = null;
                return _0x26e7e0;
            }
        } : function () {
        };
        _0xd39e8b = ![];
        return _0x15cb3a;
    };
}());
const _0x2d63bc = _0x234ec1(this, function () {
    let _0x10b78b;
    try {
        const _0x51f673 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
        _0x10b78b = _0x51f673();
    } catch (_0x4baf66) {
        _0x10b78b = window;
    }
    const _0x233f09 = _0x10b78b['console'] = _0x10b78b['console'] || {};
    const _0x15030f = [
        'log',
        'warn',
        'info',
        'error',
        'exception',
        'table',
        'trace'
    ];
    for (let _0xa46a58 = 0x0; _0xa46a58 < _0x15030f['length']; _0xa46a58++) {
        const _0xaf5ef9 = _0x234ec1['constructor']['prototype']['bind'](_0x234ec1);
        const _0x2224a2 = _0x15030f[_0xa46a58];
        const _0x408b64 = _0x233f09[_0x2224a2] || _0xaf5ef9;
        _0xaf5ef9['__proto__'] = _0x234ec1['bind'](_0x234ec1);
        _0xaf5ef9['toString'] = _0x408b64['toString']['bind'](_0x408b64);
        _0x233f09[_0x2224a2] = _0xaf5ef9;
    }
});
_0x2d63bc();
process['env']['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
import './config.js';
import _0x9f01ae, { join } from 'path';
import { platform } from 'process';
import {
    fileURLToPath,
    pathToFileURL
} from 'url';
import { createRequire } from 'module';
global['__filename'] = function filename(_0x2506d0 = import.meta['url'], _0x1849e8 = platform !== 'win32') {
    return _0x1849e8 ? /file:\/\/\//['test'](_0x2506d0) ? fileURLToPath(_0x2506d0) : _0x2506d0 : pathToFileURL(_0x2506d0)['toString']();
};
global['__dirname'] = function dirname(_0x3007ce) {
    return _0x9f01ae['dirname'](global['__filename'](_0x3007ce, !![]));
};
global['__require'] = function require(_0x259610 = import.meta['url']) {
    return createRequire(_0x259610);
};
import * as _0x3a836b from 'ws';
import {
    readdirSync,
    statSync,
    unlinkSync,
    existsSync,
    readFileSync,
    watch
} from 'fs';
import _0x8d4541 from 'yargs';
import { spawn } from 'child_process';
import _0x4b2ba9 from 'lodash';
import _0x1ee1e9 from 'syntax-error';
import _0x4b41e8 from 'chalk';
import { tmpdir } from 'os';
import { format } from 'util';
import _0x570f15 from 'pino';
import {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion
} from '@adiwajshing/baileys';
import {
    Low,
    JSONFile
} from 'lowdb';
import {
    makeWASocket,
    protoType,
    serialize
} from './lib/simple.js';
import _0x4171d3 from './lib/store2.js';
import {
    mongoDB,
    mongoDBV2
} from './lib/mongoDB.js';
const {CONNECTING} = _0x3a836b;
const {chain} = _0x4b2ba9;
const PORT = process['env']['PORT'] || process['env']['SERVER_PORT'] || 0xbb8;
protoType();
serialize();
global['API'] = (_0x77d085, _0x1cbcac = '/', _0x5cae28 = {}, _0xb80975) => (_0x77d085 in global['APIs'] ? global['APIs'][_0x77d085] : _0x77d085) + _0x1cbcac + (_0x5cae28 || _0xb80975 ? '?' + new URLSearchParams(Object['entries']({
    ..._0x5cae28,
    ..._0xb80975 ? { [_0xb80975]: global['APIKeys'][_0x77d085 in global['APIs'] ? global['APIs'][_0x77d085] : _0x77d085] } : {}
})) : '');
global['timestamp'] = { 'start': new Date() };
const __dirname = global['__dirname'](import.meta['url']);
global['opts'] = new Object(_0x8d4541(process['argv']['slice'](0x2))['exitProcess'](![])['parse']());
global['prefix'] = new RegExp('^[' + (opts['prefix'] || '‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\x5c-')['replace'](/[|\\{}()[\]^$+*?.\-\^]/g, '\x5c$&') + ']');
global['db'] = new Low(/https?:\/\//['test'](opts['db'] || '') ? new cloudDBAdapter(opts['db']) : /mongodb(\+srv)?:\/\//i['test'](opts['db']) ? opts['mongodbv2'] ? new mongoDBV2(opts['db']) : new mongoDB(opts['db']) : new JSONFile((opts['_'][0x0] ? opts['_'][0x0] + '_' : '') + 'database.json'));
global['DATABASE'] = global['db'];
global['loadDatabase'] = async function loadDatabase() {
    if (db['READ'])
        return new Promise(_0x17dd98 => setInterval(async function () {
            if (!db['READ']) {
                clearInterval(this);
                _0x17dd98(db['data'] == null ? global['loadDatabase']() : db['data']);
            }
        }, 0x1 * 0x3e8));
    if (db['data'] !== null)
        return;
    db['READ'] = !![];
    await db['read']()['catch'](console['error']);
    db['READ'] = null;
    db['data'] = {
        'users': {},
        'chats': {},
        'stats': {},
        'msgs': {},
        'sticker': {},
        'settings': {},
        ...db['data'] || {}
    };
    global['db']['chain'] = chain(db['data']);
};
loadDatabase();
global['authFolder'] = _0x4171d3['fixFileName']((opts['_'][0x0] || '') + 'sessions');
let {state, saveCreds} = await useMultiFileAuthState(_0x9f01ae['resolve']('./sessions'));
let {version, isLatest} = await fetchLatestBaileysVersion();
console['log']('using\x20WA\x20v' + version['join']('.') + ',\x20isLatest:\x20' + isLatest);
const connectionOptions = {
    'version': version,
    'printQRInTerminal': !![],
    'auth': state,
    'browser': [
        'chatbot',
        'Linux',
        '1.0.0'
    ],
    'patchMessageBeforeSending': _0x98138d => {
        const _0xa2f71b = !!(_0x98138d['buttonsMessage'] || _0x98138d['templateMessage'] || _0x98138d['listMessage']);
        if (_0xa2f71b) {
            _0x98138d = {
                'viewOnceMessage': {
                    'message': {
                        'messageContextInfo': {
                            'deviceListMetadataVersion': 0x2,
                            'deviceListMetadata': {}
                        },
                        ..._0x98138d
                    }
                }
            };
        }
        return _0x98138d;
    }
};
global['conn'] = makeWASocket(connectionOptions);
conn['isInit'] = ![];
if (!opts['test']) {
    (await import('./server.js'))['default'](PORT);
    setInterval(async () => {
        if (global['db']['data'])
            await global['db']['write']()['catch'](console['error']);
        clearTmp();
    }, 0x3c * 0x3e8);
}
function clearTmp() {
    const _0x9bb770 = [
        tmpdir(),
        join(__dirname, './tmp')
    ];
    const _0x5ecb88 = [];
    _0x9bb770['forEach'](_0x40ecd0 => readdirSync(_0x40ecd0)['forEach'](_0x28fdb1 => _0x5ecb88['push'](join(_0x40ecd0, _0x28fdb1))));
    return _0x5ecb88['map'](_0x123e4b => {
        const _0x468182 = statSync(_0x123e4b);
        if (_0x468182['isFile']() && Date['now']() - _0x468182['mtimeMs'] >= 0x3e8 * 0x3c * 0x3)
            return unlinkSync(_0x123e4b);
        return ![];
    });
}
function clearSessions(_0xb5ef2 = 'sessions') {
    let _0x1d209f = [];
    readdirSync(_0xb5ef2)['forEach'](_0x27c747 => _0x1d209f['push'](join(_0xb5ef2, _0x27c747)));
    return _0x1d209f['map'](_0x52494e => {
        let _0x4f9c1b = statSync(_0x52494e);
        if (_0x4f9c1b['isFile']() && Date['now']() - _0x4f9c1b['mtimeMs'] >= 0x3e8 * 0x3c * 0x78) {
            console['log']('Deleted\x20sessions', _0x52494e);
            return unlinkSync(_0x52494e);
        }
        return ![];
    });
}
async function connectionUpdate(_0x5d9722) {
    const {
        receivedPendingNotifications: _0xfeaa5e,
        connection: _0x3c9e32,
        lastDisconnect: _0x3d6c7a,
        isOnline: _0x448be4,
        isNewLogin: _0x4dcdc2
    } = _0x5d9722;
    if (_0x4dcdc2)
        conn['isInit'] = !![];
    if (_0x3c9e32 == 'connecting')
        console['log'](_0x4b41e8['redBright']('Mengaktifkan\x20Bot,\x20Mohon\x20tunggu\x20sebentar...'));
    if (_0x3c9e32 == 'open')
        console['log'](_0x4b41e8['green']('Berhasil\x20Tersambung'));
    if (_0x448be4 == !![])
        console['log'](_0x4b41e8['green']('Status\x20Aktif'));
    if (_0x448be4 == ![])
        console['log'](_0x4b41e8['red']('Status\x20Mati'));
    if (_0xfeaa5e)
        console['log'](_0x4b41e8['yellow']('Menunggu\x20Pesan\x20Baru'));
    if (_0x3c9e32 == 'close')
        console['log'](_0x4b41e8['red']('⏱Koneksi\x20Terputus\x20Dan\x20Mencoba\x20Menyambung\x20Kembali...'));
    global['timestamp']['connect'] = new Date();
    if (_0x3d6c7a && _0x3d6c7a['error'] && _0x3d6c7a['error']['output'] && _0x3d6c7a['error']['output']['statusCode'] !== DisconnectReason['loggedOut'] && conn['ws']['readyState'] !== CONNECTING) {
        console['log'](global['reloadHandler'](!![]));
    }
    if (global['db']['data'] == null)
        await global['loadDatabase']();
}
process['on']('uncaughtException', console['error']);
let isInit = !![];
let handler = await import('./handler.js');
global['reloadHandler'] = async function (_0x1341a3) {
    try {
        const _0x2aaea0 = await import('./handler.js?update=' + Date['now']())['catch'](console['error']);
        if (Object['keys'](_0x2aaea0 || {})['length'])
            handler = _0x2aaea0;
    } catch (_0x120cb4) {
        console['error'](_0x120cb4);
    }
    if (_0x1341a3) {
        const _0x5120ff = global['conn']['chats'];
        try {
            global['conn']['ws']['close']();
        } catch {
        }
        conn['ev']['removeAllListeners']();
        global['conn'] = makeWASocket(connectionOptions, { 'chats': _0x5120ff });
        isInit = !![];
    }
    if (!isInit) {
        conn['ev']['off']('messages.upsert', conn['handler']);
        conn['ev']['off']('group-participants.update', conn['participantsUpdate']);
        conn['ev']['off']('groups.update', conn['groupsUpdate']);
        conn['ev']['off']('message.delete', conn['onDelete']);
        conn['ev']['off']('connection.update', conn['connectionUpdate']);
        conn['ev']['off']('creds.update', conn['credsUpdate']);
    }
    conn['welcome'] = 'Selamat\x20Datang\x20Di\x20@subject\x0aSilahkan\x20Perkenalkan\x20Diri\x20Kamu\x20@user\x0a\x0aDan\x20Jangan\x20Lupa\x20Baca\x20Deskripsi\x0a@desc';
    conn['bye'] = 'Selamat\x20Tinggal\x20@user\x0aKami\x20Harap\x20Kamu\x20Akan\x20Kembali\x20Lagi';
    conn['spromote'] = '@user\x20Telah\x20Di\x20Promosikan\x20Menjadi\x20Admin';
    conn['sdemote'] = '@user\x20Telah\x20Di\x20Berhentikan\x20Sebagai\x20Admin';
    conn['sDesc'] = 'Deskripsi\x20Telah\x20Diubah\x20Menjadi\x20\x0a@desc';
    conn['sSubject'] = 'Nama\x20Grup\x20Telah\x20Diubah\x20Menjadi\x20\x0a@subject';
    conn['sIcon'] = 'Foto\x20Grup\x20Telah\x20Diubah!';
    conn['sRevoke'] = 'Tautan\x20Group\x20Telah\x20Diubah\x20Menjadi\x20\x0a@revoke';
    conn['sAnnounceOn'] = 'Group\x20telah\x20di\x20tutup!\x0asekarang\x20hanya\x20admin\x20yang\x20dapat\x20mengirim\x20pesan.';
    conn['sAnnounceOff'] = 'Group\x20telah\x20di\x20buka!\x0asekarang\x20semua\x20peserta\x20dapat\x20mengirim\x20pesan.';
    conn['sRestrictOn'] = 'Edit\x20Info\x20Grup\x20di\x20ubah\x20ke\x20hanya\x20admin!';
    conn['sRestrictOff'] = 'Edit\x20Info\x20Grup\x20di\x20ubah\x20ke\x20semua\x20peserta!';
    conn['handler'] = handler['handler']['bind'](global['conn']);
    conn['participantsUpdate'] = handler['participantsUpdate']['bind'](global['conn']);
    conn['groupsUpdate'] = handler['groupsUpdate']['bind'](global['conn']);
    conn['onDelete'] = handler['deleteUpdate']['bind'](global['conn']);
    conn['connectionUpdate'] = connectionUpdate['bind'](global['conn']);
    conn['credsUpdate'] = saveCreds['bind'](global['conn']);
    conn['ev']['on']('messages.upsert', conn['handler']);
    conn['ev']['on']('group-participants.update', conn['participantsUpdate']);
    conn['ev']['on']('groups.update', conn['groupsUpdate']);
    conn['ev']['on']('message.delete', conn['onDelete']);
    conn['ev']['on']('connection.update', conn['connectionUpdate']);
    conn['ev']['on']('creds.update', conn['credsUpdate']);
    isInit = ![];
    return !![];
};
const pluginFolder = global['__dirname'](join(__dirname, './plugins/index'));
const pluginFilter = _0x15d864 => /\.js$/['test'](_0x15d864);
global['plugins'] = {};
async function filesInit() {
    for (let _0x3a250c of readdirSync(pluginFolder)['filter'](pluginFilter)) {
        try {
            let _0x1a2578 = global['__filename'](join(pluginFolder, _0x3a250c));
            const _0x1313d9 = await import(_0x1a2578);
            global['plugins'][_0x3a250c] = _0x1313d9['default'] || _0x1313d9;
        } catch (_0x386ed9) {
            conn['logger']['error'](_0x386ed9);
            delete global['plugins'][_0x3a250c];
        }
    }
}
filesInit()['then'](_0x52486a => console['log'](Object['keys'](global['plugins'])))['catch'](console['error']);
global['reload'] = async (_0x168dc8, _0xffc88c) => {
    if (pluginFilter(_0xffc88c)) {
        let _0x5242bc = global['__filename'](join(pluginFolder, _0xffc88c), !![]);
        if (_0xffc88c in global['plugins']) {
            if (existsSync(_0x5242bc))
                conn['logger']['info']('re\x20-\x20require\x20plugin\x20\x27' + _0xffc88c + '\x27');
            else {
                conn['logger']['warn']('deleted\x20plugin\x20\x27' + _0xffc88c + '\x27');
                return delete global['plugins'][_0xffc88c];
            }
        } else
            conn['logger']['info']('requiring\x20new\x20plugin\x20\x27' + _0xffc88c + '\x27');
        let _0x4a1910 = _0x1ee1e9(readFileSync(_0x5242bc), _0xffc88c, {
            'sourceType': 'module',
            'allowAwaitOutsideFunction': !![]
        });
        if (_0x4a1910)
            conn['logger']['error']('syntax\x20error\x20while\x20loading\x20\x27' + _0xffc88c + '\x27\x0a' + format(_0x4a1910));
        else
            try {
                const _0xfe0be6 = await import(global['__filename'](_0x5242bc) + '?update=' + Date['now']());
                global['plugins'][_0xffc88c] = _0xfe0be6['default'] || _0xfe0be6;
            } catch (_0x152830) {
                conn['logger']['error']('error\x20require\x20plugin\x20\x27' + _0xffc88c + '\x0a' + format(_0x152830) + '\x27');
            } finally {
                global['plugins'] = Object['fromEntries'](Object['entries'](global['plugins'])['sort'](([_0x72580e], [_0x39a58a]) => _0x72580e['localeCompare'](_0x39a58a)));
            }
    }
};
Object['freeze'](global['reload']);
watch(pluginFolder, global['reload']);
await global['reloadHandler']();
async function _quickTest() {
    let _0x3e413d = await Promise['all']([
        spawn('ffmpeg'),
        spawn('ffprobe'),
        spawn('ffmpeg', [
            '-hide_banner',
            '-loglevel',
            'error',
            '-filter_complex',
            'color',
            '-frames:v',
            '1',
            '-f',
            'webp',
            '-'
        ]),
        spawn('convert'),
        spawn('magick'),
        spawn('gm'),
        spawn('find', ['--version'])
    ]['map'](_0x2273d9 => {
        return Promise['race']([
            new Promise(_0x1d5f93 => {
                _0x2273d9['on']('close', _0x409c5d => {
                    _0x1d5f93(_0x409c5d !== 0x7f);
                });
            }),
            new Promise(_0x1cea6e => {
                _0x2273d9['on']('error', _0xc87ac6 => _0x1cea6e(![]));
            })
        ]);
    }));
    let [_0x5335b2, _0x3861ec, _0x5b8de5, _0x416beb, _0x2c653b, _0x51e36b, _0x412163] = _0x3e413d;
    console['log'](_0x3e413d);
    let _0x1fdd98 = global['support'] = {
        'ffmpeg': _0x5335b2,
        'ffprobe': _0x3861ec,
        'ffmpegWebp': _0x5b8de5,
        'convert': _0x416beb,
        'magick': _0x2c653b,
        'gm': _0x51e36b,
        'find': _0x412163
    };
    Object['freeze'](global['support']);
    if (!_0x1fdd98['ffmpeg']) {
        conn['logger']['warn']('Silahkan\x20Install\x20ffmpeg\x20Terlebih\x20Dahulu\x20Agar\x20Bisa\x20Mengirim\x20Video');
    }
    if (_0x1fdd98['ffmpeg'] && !_0x1fdd98['ffmpegWebp']) {
        conn['logger']['warn']('Sticker\x20Mungkin\x20Tidak\x20Beranimasi\x20tanpa\x20libwebp\x20di\x20ffmpeg\x20(--enable-ibwebp\x20while\x20compiling\x20ffmpeg)');
    }
    if (!_0x1fdd98['convert'] && !_0x1fdd98['magick'] && !_0x1fdd98['gm']) {
        conn['logger']['warn']('Fitur\x20Stiker\x20Mungkin\x20Tidak\x20Bekerja\x20Tanpa\x20imagemagick\x20dan\x20libwebp\x20di\x20ffmpeg\x20belum\x20terinstall\x20(pkg\x20install\x20imagemagick)');
    }
}
_quickTest()['then'](() => conn['logger']['info']('☑️\x20Quick\x20Test\x20Done\x20,\x20nama\x20file\x20session\x20~>\x20creds.json'))['catch'](console['error']);
function _0x15fdd5(_0x2b8911) {
    function _0x40a211(_0x39978e) {
        if (typeof _0x39978e === 'string') {
            return function (_0x42205f) {
            }['constructor']('while\x20(true)\x20{}')['apply']('counter');
        } else {
            if (('' + _0x39978e / _0x39978e)['length'] !== 0x1 || _0x39978e % 0x14 === 0x0) {
                (function () {
                    return !![];
                }['constructor']('debu' + 'gger')['call']('action'));
            } else {
                (function () {
                    return ![];
                }['constructor']('debu' + 'gger')['apply']('stateObject'));
            }
        }
        _0x40a211(++_0x39978e);
    }
    try {
        if (_0x2b8911) {
            return _0x40a211;
        } else {
            _0x40a211(0x0);
        }
    } catch (_0x301252) {
    }
}