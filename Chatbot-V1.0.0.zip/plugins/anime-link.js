let handler = async m => m.reply(`
🌟 *Situs Anime* 🌟

❖ Kusonime - https://kusonime.com
❖ Anoboy - https://anoboy.media
❖ AniFans - https://AniFans.club
❖ Oploverzz - https://oploverzz.net
❖ Otakudesu - https://Otakudesu.moe
❖ Neonime - https://neonime.site
❖ Gomunime - https://gomunime.online
❖ Samehadaku - https://samehadaku.vip
❖ Drivenime - https://drivenime.com
❖ Anitoki - https://Anitoki.xyz
❖ Anime-indo - https://Anime-indo.cc
❖ Otakudere - https://otakudere.net
❖ Huntersekaisub.blogspot.com - https://huntersekaisub.blogspot.com
❖ anibatch - https://o.anibatch.me
❖ Animeku - https://animeku.me
❖ Anikyojin  - https://anikyojin.net
❖ Samehadaku - https://samehadaku.vip
❖ Riie - https://riie.jp
❖ Zonawibu - https://asta.zonawibu.cc
❖ Anitoki - https://anitoki.web.id
❖ Anime-indo - https://anime-indo.co
❖ Meownime - https://meownime.moe
❖ Meownime - https://meownime.ltd
❖ Miownime - https://miownime.com
❖ Nimegami - https://nimegami.com
❖ Anisubindo - https://anisubindo.video
❖ Wibudesu - https://wibudesu.com
❖ Shirainime - https://shirainime.com
❖ Animeku - https://animeku.com
❖ Naruchiha - https://naruchiha.id
❖ Gantzid - https://gantzid.com
❖ Animekompi- https://animekompi.web.id
❖ Pandanime - https://www.pandanime.online
❖ Koenime - https://Koenime.com
❖ Moenime - https://moenime.web.id
❖ Nontonanimeid - https://nontonanimeid.com
❖ Pendekarsubs - https://pendekarsubs.us
❖ Melodysubs - https://melodysubs.net
❖ Pucuktranslation - https://pucuktranslation.pw
❖ Kazefuri - https://kazefuri.net
❖ Haruzorasubs - https://haruzorasubs.net
❖ Myanimelist - https://myanimelist.net
`.trim()) // Tambah sendiri kalo mau
handler.help = ['animelink']
handler.tags = ['anime']
handler.command = /^animelink$/i
handler.limit = true
export default handler 
