import { smsg } from './lib/simple.js';
import { format } from 'util';
import { fileURLToPath } from 'url';
import _0x26ec8c, { join } from 'path';
import {
    unwatchFile,
    watchFile
} from 'fs';
import _0x13e02f from 'chalk';
import _0x13b767 from 'fs';
import _0x111731 from 'node-fetch';
import _0x21dac8 from 'moment-timezone';
const {proto} = (await import('@adiwajshing/baileys'))['default'];
const isNumber = _0x469cac => typeof _0x469cac === 'number' && !isNaN(_0x469cac);
const delay = _0x208bf8 => isNumber(_0x208bf8) && new Promise(_0x259d28 => setTimeout(function () {
    clearTimeout(this);
    _0x259d28();
}, _0x208bf8));
export async function handler(_0x57ca18) {
    this['msgqueque'] = this['msgqueque'] || [];
    if (!_0x57ca18)
        return;
    this['pushMessage'](_0x57ca18['messages'])['catch'](console['error']);
    let _0x1d4c93 = _0x57ca18['messages'][_0x57ca18['messages']['length'] - 0x1];
    global['img'] = 'https://telegra.ph/file/e4a2f4339da8a32ad20a1.jpg';
    if (!_0x1d4c93)
        return;
    if (global['db']['data'] == null)
        await global['loadDatabase']();
    try {
        _0x1d4c93 = smsg(this, _0x1d4c93) || _0x1d4c93;
        if (!_0x1d4c93)
            return;
        _0x1d4c93['exp'] = 0x0;
        _0x1d4c93['limit'] = ![];
        try {
            let _0x470a7b = global['db']['data']['users'][_0x1d4c93['sender']];
            if (typeof _0x470a7b !== 'object')
                global['db']['data']['users'][_0x1d4c93['sender']] = {};
            if (_0x470a7b) {
                if (!isNumber(_0x470a7b['exp']))
                    _0x470a7b['exp'] = 0x0;
                if (!isNumber(_0x470a7b['limit']))
                    _0x470a7b['limit'] = 0x32;
                if (!isNumber(_0x470a7b['lastclaim']))
                    _0x470a7b['lastclaim'] = 0x0;
                if (!isNumber(_0x470a7b['pasangan']))
                    _0x470a7b['pasangan'] = '';
                if (!('registered' in _0x470a7b))
                    _0x470a7b['registered'] = ![];
                if (!_0x470a7b['registered']) {
                    if (!('name' in _0x470a7b))
                        _0x470a7b['name'] = _0x1d4c93['name'];
                    if (!isNumber(_0x470a7b['age']))
                        _0x470a7b['age'] = -0x1;
                    if (!isNumber(_0x470a7b['regTime']))
                        _0x470a7b['regTime'] = -0x1;
                }
                if (!isNumber(_0x470a7b['afk']))
                    _0x470a7b['afk'] = -0x1;
                if (!('afkReason' in _0x470a7b))
                    _0x470a7b['afkReason'] = '';
                if (!('banned' in _0x470a7b))
                    _0x470a7b['banned'] = ![];
                if (!isNumber(_0x470a7b['warning']))
                    _0x470a7b['warning'] = 0x0;
                if (!isNumber(_0x470a7b['warn']))
                    _0x470a7b['warn'] = 0x0;
                if (!isNumber(_0x470a7b['level']))
                    _0x470a7b['level'] = 0x0;
                if (!('role' in _0x470a7b))
                    _0x470a7b['role'] = 'Beginner';
                if (!('autolevelup' in _0x470a7b))
                    _0x470a7b['autolevelup'] = !![];
                if (!isNumber(_0x470a7b['money']))
                    _0x470a7b['money'] = 0x0;
                if (!isNumber(_0x470a7b['atm']))
                    _0x470a7b['atm'] = 0x0;
                if (!isNumber(_0x470a7b['fullatm']))
                    _0x470a7b['fullatm'] = 0x0;
                if (!isNumber(_0x470a7b['bank']))
                    _0x470a7b['bank'] = 0x0;
                if (!isNumber(_0x470a7b['health']))
                    _0x470a7b['health'] = 0x64;
                if (!isNumber(_0x470a7b['potion']))
                    _0x470a7b['potion'] = 0x0;
                if (!isNumber(_0x470a7b['trash']))
                    _0x470a7b['trash'] = 0x0;
                if (!isNumber(_0x470a7b['wood']))
                    _0x470a7b['wood'] = 0x0;
                if (!isNumber(_0x470a7b['rock']))
                    _0x470a7b['rock'] = 0x0;
                if (!isNumber(_0x470a7b['string']))
                    _0x470a7b['string'] = 0x0;
                if (!isNumber(_0x470a7b['petFood']))
                    _0x470a7b['petFood'] = 0x0;
                if (!isNumber(_0x470a7b['emerald']))
                    _0x470a7b['emerald'] = 0x0;
                if (!isNumber(_0x470a7b['diamond']))
                    _0x470a7b['diamond'] = 0x0;
                if (!isNumber(_0x470a7b['gold']))
                    _0x470a7b['gold'] = 0x0;
                if (!isNumber(_0x470a7b['iron']))
                    _0x470a7b['iron'] = 0x0;
                if (!isNumber(_0x470a7b['upgrader']))
                    _0x470a7b['upgrader'] = 0x0;
                if (!isNumber(_0x470a7b['common']))
                    _0x470a7b['common'] = 0x0;
                if (!isNumber(_0x470a7b['uncommon']))
                    _0x470a7b['uncommon'] = 0x0;
                if (!isNumber(_0x470a7b['mythic']))
                    _0x470a7b['mythic'] = 0x0;
                if (!isNumber(_0x470a7b['legendary']))
                    _0x470a7b['legendary'] = 0x0;
                if (!isNumber(_0x470a7b['superior']))
                    _0x470a7b['superior'] = 0x0;
                if (!isNumber(_0x470a7b['pet']))
                    _0x470a7b['pet'] = 0x0;
                if (!isNumber(_0x470a7b['horse']))
                    _0x470a7b['horse'] = 0x0;
                if (!isNumber(_0x470a7b['horseexp']))
                    _0x470a7b['horseexp'] = 0x0;
                if (!isNumber(_0x470a7b['cat']))
                    _0x470a7b['cat'] = 0x0;
                if (!isNumber(_0x470a7b['catexp']))
                    _0x470a7b['catexp'] = 0x0;
                if (!isNumber(_0x470a7b['fox']))
                    _0x470a7b['fox'] = 0x0;
                if (!isNumber(_0x470a7b['foxhexp']))
                    _0x470a7b['foxexp'] = 0x0;
                if (!isNumber(_0x470a7b['dog']))
                    _0x470a7b['dog'] = 0x0;
                if (!isNumber(_0x470a7b['dogexp']))
                    _0x470a7b['dogexp'] = 0x0;
                if (!isNumber(_0x470a7b['robo']))
                    _0x470a7b['robo'] = 0x0;
                if (!isNumber(_0x470a7b['roboxp']))
                    _0x470a7b['roboxp'] = 0x0;
                if (!isNumber(_0x470a7b['horselastfeed']))
                    _0x470a7b['horselastfeed'] = 0x0;
                if (!isNumber(_0x470a7b['catlastfeed']))
                    _0x470a7b['catlastfeed'] = 0x0;
                if (!isNumber(_0x470a7b['foxlastfeed']))
                    _0x470a7b['foxlastfeed'] = 0x0;
                if (!isNumber(_0x470a7b['doglastfeed']))
                    _0x470a7b['doglastfeed'] = 0x0;
                if (!isNumber(_0x470a7b['armor']))
                    _0x470a7b['armor'] = 0x0;
                if (!isNumber(_0x470a7b['armordurability']))
                    _0x470a7b['armordurability'] = 0x0;
                if (!isNumber(_0x470a7b['sword']))
                    _0x470a7b['sword'] = 0x0;
                if (!isNumber(_0x470a7b['sworddurability']))
                    _0x470a7b['sworddurability'] = 0x0;
                if (!isNumber(_0x470a7b['pickaxe']))
                    _0x470a7b['pickaxe'] = 0x0;
                if (!isNumber(_0x470a7b['pickaxedurability']))
                    _0x470a7b['pickaxedurability'] = 0x0;
                if (!isNumber(_0x470a7b['fishingrod']))
                    _0x470a7b['fishingrod'] = 0x0;
                if (!isNumber(_0x470a7b['fishingroddurability']))
                    _0x470a7b['fishingroddurability'] = 0x0;
                if (!isNumber(_0x470a7b['lastclaim']))
                    _0x470a7b['lastclaim'] = 0x0;
                if (!isNumber(_0x470a7b['lastadventure']))
                    _0x470a7b['lastadventure'] = 0x0;
                if (!isNumber(_0x470a7b['lastfishing']))
                    _0x470a7b['lastfishing'] = 0x0;
                if (!isNumber(_0x470a7b['lastdungeon']))
                    _0x470a7b['lastdungeon'] = 0x0;
                if (!isNumber(_0x470a7b['lastduel']))
                    _0x470a7b['lastduel'] = 0x0;
                if (!isNumber(_0x470a7b['lastmining']))
                    _0x470a7b['lastmining'] = 0x0;
                if (!isNumber(_0x470a7b['lasthunt']))
                    _0x470a7b['lasthunt'] = 0x0;
                if (!isNumber(_0x470a7b['lastweekly']))
                    _0x470a7b['lastweekly'] = 0x0;
                if (!isNumber(_0x470a7b['lastmonthly']))
                    _0x470a7b['lastmonthly'] = 0x0;
                if (!isNumber(_0x470a7b['lastbunga']))
                    _0x470a7b['lastbunga'] = 0x0;
                if (!isNumber(_0x470a7b['note']))
                    _0x470a7b['note'] = 0x0;
                if (!isNumber(_0x470a7b['premium']))
                    _0x470a7b['premium'] = ![];
                if (!isNumber(_0x470a7b['premiumTime']))
                    _0x470a7b['premiumTime'] = 0x0;
                if (!isNumber(_0x470a7b['limitjoin']))
                    _0x470a7b['limitjoin'] = 0x0;
            } else
                global['db']['data']['users'][_0x1d4c93['sender']] = {
                    'exp': 0x0,
                    'limit': 0x32,
                    'lastclaim': 0x0,
                    'registered': ![],
                    'name': _0x1d4c93['name'],
                    'pasangan': '',
                    'age': -0x1,
                    'regTime': -0x1,
                    'afk': -0x1,
                    'afkReason': '',
                    'banned': ![],
                    'warn': 0x0,
                    'level': 0x0,
                    'role': 'Beginner',
                    'autolevelup': !![],
                    'money': 0x0,
                    'bank': 0x0,
                    'atm': 0x0,
                    'fullatm': 0x0,
                    'health': 0x64,
                    'potion': 0xa,
                    'trash': 0x0,
                    'wood': 0x0,
                    'rock': 0x0,
                    'string': 0x0,
                    'emerald': 0x0,
                    'diamond': 0x0,
                    'gold': 0x0,
                    'iron': 0x0,
                    'upgrader': 0x0,
                    'common': 0x0,
                    'uncommon': 0x0,
                    'mythic': 0x0,
                    'legendary': 0x0,
                    'superior': 0x0,
                    'pet': 0x0,
                    'horse': 0x0,
                    'horseexp': 0x0,
                    'cat': 0x0,
                    'catngexp': 0x0,
                    'fox': 0x0,
                    'foxexp': 0x0,
                    'dog': 0x0,
                    'dogexp': 0x0,
                    'horselastfeed': 0x0,
                    'catlastfeed': 0x0,
                    'foxlastfeed': 0x0,
                    'doglastfeed': 0x0,
                    'armor': 0x0,
                    'armordurability': 0x0,
                    'sword': 0x0,
                    'sworddurability': 0x0,
                    'pickaxe': 0x0,
                    'pickaxedurability': 0x0,
                    'fishingrod': 0x0,
                    'fishingroddurability': 0x0,
                    'lastclaim': 0x0,
                    'lastadventure': 0x0,
                    'lastfishing': 0x0,
                    'lastdungeon': 0x0,
                    'lastduel': 0x0,
                    'lastmining': 0x0,
                    'lasthunt': 0x0,
                    'lastweekly': 0x0,
                    'lastmonthly': 0x0,
                    'lastbunga': 0x0,
                    'note': 0x0,
                    'premium': ![],
                    'premiumTime': 0x0,
                    'limitjoin': 0x0
                };
            let _0x5085be = global['db']['data']['chats'][_0x1d4c93['chat']];
            if (typeof _0x5085be !== 'object')
                global['db']['data']['chats'][_0x1d4c93['chat']] = {};
            const _0x3c74db = {};
            _0x3c74db['isBanned'] = ![];
            _0x3c74db['welcome'] = !![];
            _0x3c74db['detect'] = ![];
            _0x3c74db['sWelcome'] = '';
            _0x3c74db['sBye'] = '';
            _0x3c74db['sPromote'] = '';
            _0x3c74db['sDemote'] = '';
            _0x3c74db['delete'] = ![];
            _0x3c74db['antiLink'] = ![];
            _0x3c74db['viewonce'] = ![];
            _0x3c74db['antiBadword'] = ![];
            _0x3c74db['simi'] = ![];
            _0x3c74db['expired'] = 0x0;
            _0x3c74db['nsfw'] = ![];
            _0x3c74db['premnsfw'] = ![];
            if (_0x5085be) {
                if (!('isBanned' in _0x5085be))
                    _0x5085be['isBanned'] = ![];
                if (!('welcome' in _0x5085be))
                    _0x5085be['welcome'] = !![];
                if (!('detect' in _0x5085be))
                    _0x5085be['detect'] = ![];
                if (!('sWelcome' in _0x5085be))
                    _0x5085be['sWelcome'] = '';
                if (!('sBye' in _0x5085be))
                    _0x5085be['sBye'] = '';
                if (!('sPromote' in _0x5085be))
                    _0x5085be['sPromote'] = '';
                if (!('sDemote' in _0x5085be))
                    _0x5085be['sDemote'] = '';
                if (!('delete' in _0x5085be))
                    _0x5085be['delete'] = !![];
                if (!('antiLink' in _0x5085be))
                    _0x5085be['antiLink'] = ![];
                if (!('viewonce' in _0x5085be))
                    _0x5085be['viewonce'] = ![];
                if (!('antiBadword' in _0x5085be))
                    _0x5085be['antiBadword'] = ![];
                if (!('simi' in _0x5085be))
                    _0x5085be['simi'] = ![];
                if (!('nsfw' in _0x5085be))
                    _0x5085be['nsfw'] = ![];
                if (!('premnsfw' in _0x5085be))
                    _0x5085be['premnsfw'] = ![];
                if (!isNumber(_0x5085be['expired']))
                    _0x5085be['expired'] = 0x0;
            } else
                global['db']['data']['chats'][_0x1d4c93['chat']] = _0x3c74db;
            let _0x11038d = global['db']['data']['users'][_0x1d4c93['sender']]['akinator'];
            if (typeof _0x11038d !== 'object')
                global['db']['data']['users'][_0x1d4c93['sender']]['akinator'] = {};
            const _0x1c8b02 = {};
            _0x1c8b02['sesi'] = ![];
            _0x1c8b02['server'] = null;
            _0x1c8b02['frontaddr'] = null;
            _0x1c8b02['session'] = null;
            _0x1c8b02['signature'] = null;
            _0x1c8b02['question'] = null;
            _0x1c8b02['progression'] = null;
            _0x1c8b02['step'] = null;
            _0x1c8b02['soal'] = null;
            if (_0x11038d) {
                if (!('sesi' in _0x11038d))
                    _0x11038d['sesi'] = ![];
                if (!('server' in _0x11038d))
                    _0x11038d['server'] = null;
                if (!('frontaddr' in _0x11038d))
                    _0x11038d['frontaddr'] = null;
                if (!('session' in _0x11038d))
                    _0x11038d['session'] = null;
                if (!('signature' in _0x11038d))
                    _0x11038d['signature'] = null;
                if (!('question' in _0x11038d))
                    _0x11038d['question'] = null;
                if (!('progression' in _0x11038d))
                    _0x11038d['progression'] = null;
                if (!('step' in _0x11038d))
                    _0x11038d['step'] = null;
                if (!('soal' in _0x11038d))
                    _0x11038d['soal'] = null;
            } else
                global['db']['data']['users'][_0x1d4c93['sender']]['akinator'] = _0x1c8b02;
            let _0x186f04 = global['db']['data']['settings'][this['user']['jid']];
            if (typeof _0x186f04 !== 'object')
                global['db']['data']['settings'][this['user']['jid']] = {};
            const _0x58648a = {};
            _0x58648a['self'] = ![];
            _0x58648a['autoread'] = !![];
            _0x58648a['jadibot'] = ![];
            _0x58648a['restrict'] = !![];
            _0x58648a['autorestart'] = !![];
            _0x58648a['restartDB'] = 0x0;
            if (_0x186f04) {
                if (!('self' in _0x186f04))
                    _0x186f04['self'] = ![];
                if (!('autoread' in _0x186f04))
                    _0x186f04['autoread'] = !![];
                if (!('restrict' in _0x186f04))
                    _0x186f04['restrict'] = !![];
                if (!('jadibot' in _0x186f04))
                    _0x186f04['jadibot'] = ![];
                if (!('autorestart' in _0x186f04))
                    _0x186f04['autorestart'] = !![];
                if (!('restartDB' in _0x186f04))
                    _0x186f04['restartDB'] = 0x0;
            } else
                global['db']['data']['settings'][this['user']['jid']] = _0x58648a;
        } catch (_0x453009) {
            console['error'](_0x453009);
        }
        if (opts['nyimak'])
            return;
        if (!_0x1d4c93['fromMe'] && opts['self'])
            return;
        if (opts['pconly'] && _0x1d4c93['chat']['endsWith']('g.us'))
            return;
        if (opts['gconly'] && !_0x1d4c93['chat']['endsWith']('g.us'))
            return;
        if (opts['swonly'] && _0x1d4c93['chat'] !== 'status@broadcast')
            return;
        if (typeof _0x1d4c93['text'] !== 'string')
            _0x1d4c93['text'] = '';
        const _0x55fb92 = [
            conn['decodeJid'](global['conn']['user']['id']),
            ...global['owner']['map'](([_0x39b20d]) => _0x39b20d)
        ]['map'](_0x3d248a => _0x3d248a['replace'](/[^0-9]/g, '') + '@s.whatsapp.net')['includes'](_0x1d4c93['sender']);
        const _0x4f6b3e = _0x55fb92 || _0x1d4c93['fromMe'];
        const _0x5c4b76 = _0x4f6b3e || global['mods']['map'](_0x2c3515 => _0x2c3515['replace'](/[^0-9]/g, '') + '@s.whatsapp.net')['includes'](_0x1d4c93['sender']);
        const _0x3fb8b5 = _0x55fb92 || db['data']['users'][_0x1d4c93['sender']]['premiumTime'] > 0x0;
        if (opts['queque'] && _0x1d4c93['text'] && !(_0x5c4b76 || _0x3fb8b5)) {
            let _0x4b8e42 = this['msgqueque'], _0x1ae673 = 0x3e8 * 0x5;
            const _0x5bfcc0 = _0x4b8e42[_0x4b8e42['length'] - 0x1];
            _0x4b8e42['push'](_0x1d4c93['id'] || _0x1d4c93['key']['id']);
            setInterval(async function () {
                if (_0x4b8e42['indexOf'](_0x5bfcc0) === -0x1)
                    clearInterval(this);
                await delay(_0x1ae673);
            }, _0x1ae673);
        }
        if (_0x1d4c93['isBaileys'])
            return;
        _0x1d4c93['exp'] += Math['ceil'](Math['random']() * 0xa);
        let _0x1a7d8c;
        let _0x28360b = global['db']['data'] && global['db']['data']['users'] && global['db']['data']['users'][_0x1d4c93['sender']];
        const _0x1f5a0f = (_0x1d4c93['isGroup'] ? (conn['chats'][_0x1d4c93['chat']] || {})['metadata'] || await this['groupMetadata'](_0x1d4c93['chat'])['catch'](_0x31eaf3 => null) : {}) || {};
        const _0x3d754c = (_0x1d4c93['isGroup'] ? _0x1f5a0f['participants'] : []) || [];
        const _0xb5c4d9 = (_0x1d4c93['isGroup'] ? _0x3d754c['find'](_0x33a75c => conn['decodeJid'](_0x33a75c['id']) === _0x1d4c93['sender']) : {}) || {};
        const _0x7bcd2f = (_0x1d4c93['isGroup'] ? _0x3d754c['find'](_0x5e9827 => conn['decodeJid'](_0x5e9827['id']) == this['user']['jid']) : {}) || {};
        const _0x239afb = _0xb5c4d9?.['admin'] == 'superadmin' || ![];
        const _0x193250 = _0x239afb || _0xb5c4d9?.['admin'] == 'admin' || ![];
        const _0x3830e0 = _0x7bcd2f?.['admin'] || ![];
        const _0x133883 = _0x26ec8c['join'](_0x26ec8c['dirname'](fileURLToPath(import.meta['url'])), './plugins');
        for (let _0x23d07e in global['plugins']) {
            let _0x3888db = global['plugins'][_0x23d07e];
            if (!_0x3888db)
                continue;
            if (_0x3888db['disabled'])
                continue;
            const _0x1d6806 = join(_0x133883, _0x23d07e);
            if (typeof _0x3888db['all'] === 'function') {
                try {
                    const _0x4f63d6 = {};
                    _0x4f63d6['chatUpdate'] = _0x57ca18;
                    _0x4f63d6['__dirname'] = _0x133883;
                    _0x4f63d6['__filename'] = _0x1d6806;
                    await _0x3888db['all']['call'](this, _0x1d4c93, _0x4f63d6);
                } catch (_0x391603) {
                    console['error'](_0x391603);
                    for (let [_0x1f34e9] of global['owner']['filter'](([_0x134dca, _0x5de13f, _0xbd7c90]) => _0xbd7c90 && _0x134dca)) {
                        let _0x1e5bbe = (await conn['onWhatsApp'](_0x1f34e9))[0x0] || {};
                        if (_0x1e5bbe['exists'])
                            _0x1d4c93['reply'](('*Plugin:*\x20' + _0x23d07e + '\x0a*Sender:*\x20' + _0x1d4c93['sender'] + '\x0a*Chat:*\x20' + _0x1d4c93['chat'] + '\x0a*Command:*\x20' + _0x1d4c93['text'] + '\x0a\x0a```' + format(_0x391603) + '```')['trim'](), _0x1e5bbe['jid']);
                    }
                }
            }
            if (!opts['restrict'])
                if (_0x3888db['tags'] && _0x3888db['tags']['includes']('admin')) {
                    continue;
                }
            const _0x16d58e = _0x440a13 => _0x440a13['replace'](/[|\\{}()[\]^$+*?.]/g, '\x5c$&');
            let _0xb58000 = _0x3888db['customPrefix'] ? _0x3888db['customPrefix'] : conn['prefix'] ? conn['prefix'] : global['prefix'];
            let _0x27dee1 = (_0xb58000 instanceof RegExp ? [[
                    _0xb58000['exec'](_0x1d4c93['text']),
                    _0xb58000
                ]] : Array['isArray'](_0xb58000) ? _0xb58000['map'](_0x25ad30 => {
                let _0x1f1544 = _0x25ad30 instanceof RegExp ? _0x25ad30 : new RegExp(_0x16d58e(_0x25ad30));
                return [
                    _0x1f1544['exec'](_0x1d4c93['text']),
                    _0x1f1544
                ];
            }) : typeof _0xb58000 === 'string' ? [[
                    new RegExp(_0x16d58e(_0xb58000))['exec'](_0x1d4c93['text']),
                    new RegExp(_0x16d58e(_0xb58000))
                ]] : [[
                    [],
                    new RegExp()
                ]])['find'](_0x2cbbf0 => _0x2cbbf0[0x1]);
            if (typeof _0x3888db['before'] === 'function') {
                if (await _0x3888db['before']['call'](this, _0x1d4c93, {
                        'match': _0x27dee1,
                        'conn': this,
                        'participants': _0x3d754c,
                        'groupMetadata': _0x1f5a0f,
                        'user': _0xb5c4d9,
                        'bot': _0x7bcd2f,
                        'isROwner': _0x55fb92,
                        'isOwner': _0x4f6b3e,
                        'isRAdmin': _0x239afb,
                        'isAdmin': _0x193250,
                        'isBotAdmin': _0x3830e0,
                        'isPrems': _0x3fb8b5,
                        'chatUpdate': _0x57ca18,
                        '__dirname': _0x133883,
                        '__filename': _0x1d6806
                    }))
                    continue;
            }
            if (typeof _0x3888db !== 'function')
                continue;
            if (_0x1a7d8c = (_0x27dee1[0x0] || '')[0x0]) {
                let _0x8b615 = _0x1d4c93['text']['replace'](_0x1a7d8c, '');
                let [_0x5c40aa, ..._0x46a126] = _0x8b615['trim']()['split']` `['filter'](_0x239fa0 => _0x239fa0);
                _0x46a126 = _0x46a126 || [];
                let _0x4e1782 = _0x8b615['trim']()['split']` `['slice'](0x1);
                let _0x55258b = _0x4e1782['join']` `;
                _0x5c40aa = (_0x5c40aa || '')['toLowerCase']();
                let _0x324dcf = _0x3888db['fail'] || global['dfail'];
                let _0x4c2df2 = _0x3888db['command'] instanceof RegExp ? _0x3888db['command']['test'](_0x5c40aa) : Array['isArray'](_0x3888db['command']) ? _0x3888db['command']['some'](_0x479081 => _0x479081 instanceof RegExp ? _0x479081['test'](_0x5c40aa) : _0x479081 === _0x5c40aa) : typeof _0x3888db['command'] === 'string' ? _0x3888db['command'] === _0x5c40aa : ![];
                if (!_0x4c2df2)
                    continue;
                _0x1d4c93['plugin'] = _0x23d07e;
                if (_0x1d4c93['chat'] in global['db']['data']['chats'] || _0x1d4c93['sender'] in global['db']['data']['users']) {
                    let _0x136bdf = global['db']['data']['chats'][_0x1d4c93['chat']];
                    let _0x59923b = global['db']['data']['users'][_0x1d4c93['sender']];
                    if (_0x23d07e != 'owner-unbanchat.js' && _0x23d07e != 'owner-exec.js' && _0x23d07e != 'owner-exec2.js' && _0x23d07e != 'tool-delete.js' && _0x136bdf?.['isBanned'])
                        return;
                    if (_0x23d07e != 'owner-unbanuser.js' && _0x59923b?.['banned'])
                        return;
                }
                if (_0x3888db['rowner'] && _0x3888db['owner'] && !(_0x55fb92 || _0x4f6b3e)) {
                    _0x324dcf('owner', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['rowner'] && !_0x55fb92) {
                    _0x324dcf('rowner', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['owner'] && !_0x4f6b3e) {
                    _0x324dcf('owner', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['mods'] && !_0x5c4b76) {
                    _0x324dcf('mods', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['premium'] && !_0x3fb8b5) {
                    _0x324dcf('premium', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['group'] && !_0x1d4c93['isGroup']) {
                    _0x324dcf('group', _0x1d4c93, this);
                    continue;
                } else if (_0x3888db['botAdmin'] && !_0x3830e0) {
                    _0x324dcf('botAdmin', _0x1d4c93, this);
                    continue;
                } else if (_0x3888db['admin'] && !_0x193250) {
                    _0x324dcf('admin', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['private'] && _0x1d4c93['isGroup']) {
                    _0x324dcf('private', _0x1d4c93, this);
                    continue;
                }
                if (_0x3888db['register'] == !![] && _0x28360b['registered'] == ![]) {
                    _0x324dcf('unreg', _0x1d4c93, this);
                    continue;
                }
                _0x1d4c93['isCommand'] = !![];
                let _0x141201 = 'exp' in _0x3888db ? parseInt(_0x3888db['exp']) : 0x11;
                if (_0x141201 > 0xc8)
                    _0x1d4c93['reply']('Ngecit\x20-_-');
                else
                    _0x1d4c93['exp'] += _0x141201;
                if (!_0x3fb8b5 && _0x3888db['limit'] && global['db']['data']['users'][_0x1d4c93['sender']]['limit'] < _0x3888db['limit'] * 0x1) {
                    this['reply'](_0x1d4c93['chat'], 'Limit\x20Kamu\x20Habis,\x20Beli\x20Dengan\x20Cara\x20*' + _0x1a7d8c + 'buy\x20limit*', _0x1d4c93);
                    continue;
                }
                if (_0x3888db['level'] > _0x28360b['level']) {
                    this['reply'](_0x1d4c93['chat'], 'Diperlukan\x20Level\x20' + _0x3888db['level'] + '\x20Untuk\x20Menggunakan\x20Perintah\x20Ini\x0a*Level\x20Kamu:*\x20' + _0x28360b['level'], _0x1d4c93);
                    continue;
                }
                const _0x435af0 = {};
                _0x435af0['match'] = _0x27dee1;
                _0x435af0['usedPrefix'] = _0x1a7d8c;
                _0x435af0['noPrefix'] = _0x8b615;
                _0x435af0['_args'] = _0x4e1782;
                _0x435af0['args'] = _0x46a126;
                _0x435af0['command'] = _0x5c40aa;
                _0x435af0['text'] = _0x55258b;
                _0x435af0['conn'] = this;
                _0x435af0['participants'] = _0x3d754c;
                _0x435af0['groupMetadata'] = _0x1f5a0f;
                _0x435af0['user'] = _0xb5c4d9;
                _0x435af0['bot'] = _0x7bcd2f;
                _0x435af0['isROwner'] = _0x55fb92;
                _0x435af0['isOwner'] = _0x4f6b3e;
                _0x435af0['isRAdmin'] = _0x239afb;
                _0x435af0['isAdmin'] = _0x193250;
                _0x435af0['isBotAdmin'] = _0x3830e0;
                _0x435af0['isPrems'] = _0x3fb8b5;
                _0x435af0['chatUpdate'] = _0x57ca18;
                _0x435af0['__dirname'] = _0x133883;
                _0x435af0['__filename'] = _0x1d6806;
                let _0x52ab05 = _0x435af0;
                try {
                    await _0x3888db['call'](this, _0x1d4c93, _0x52ab05);
                    if (!_0x3fb8b5)
                        _0x1d4c93['limit'] = _0x1d4c93['limit'] || _0x3888db['limit'] || ![];
                } catch (_0xcecd92) {
                    _0x1d4c93['error'] = _0xcecd92;
                    console['error'](_0xcecd92);
                    if (_0xcecd92) {
                        let _0x425224 = format(_0xcecd92);
                        for (let _0x3bbc68 of Object['values'](global['APIKeys']))
                            _0x425224 = _0x425224['replace'](new RegExp(_0x3bbc68, 'g'), '#HIDDEN#');
                        if (_0xcecd92['name'])
                            for (let [_0x5ce27a] of global['owner']['filter'](([_0x372f86, _0x3b02c8, _0x49b413]) => _0x49b413 && _0x372f86)) {
                                let _0x5510d1 = (await conn['onWhatsApp'](_0x5ce27a))[0x0] || {};
                                if (_0x5510d1['exists'])
                                    _0x1d4c93['reply'](('*🗂️\x20Plugin:*\x20' + _0x1d4c93['plugin'] + '\x0a*👤\x20Sender:*\x20' + _0x1d4c93['sender'] + '\x0a*💬\x20Chat:*\x20' + _0x1d4c93['chat'] + '\x0a*💻\x20Command:*\x20' + _0x1a7d8c + _0x5c40aa + '\x20' + _0x46a126['join']('\x20') + '\x0a📄\x20*Error\x20Logs:*\x0a\x0a```' + _0x425224 + '```')['trim'](), _0x5510d1['jid']);
                            }
                        _0x1d4c93['reply'](_0x425224);
                    }
                } finally {
                    if (typeof _0x3888db['after'] === 'function') {
                        try {
                            await _0x3888db['after']['call'](this, _0x1d4c93, _0x52ab05);
                        } catch (_0x15c72c) {
                            console['error'](_0x15c72c);
                        }
                    }
                }
                break;
            }
        }
    } catch (_0x37f2ae) {
        console['error'](_0x37f2ae);
    } finally {
        if (opts['queque'] && _0x1d4c93['text']) {
            const _0x4bb1de = this['msgqueque']['indexOf'](_0x1d4c93['id'] || _0x1d4c93['key']['id']);
            if (_0x4bb1de !== -0x1)
                this['msgqueque']['splice'](_0x4bb1de, 0x1);
        }
        let _0x59a49a, _0x4f652f = global['db']['data']['stats'];
        if (_0x1d4c93) {
            if (_0x1d4c93['sender'] && (_0x59a49a = global['db']['data']['users'][_0x1d4c93['sender']])) {
                _0x59a49a['exp'] += _0x1d4c93['exp'];
                _0x59a49a['limit'] -= _0x1d4c93['limit'] * 0x1;
            }
            let _0x42f423;
            if (_0x1d4c93['plugin']) {
                let _0x577d8c = +new Date();
                if (_0x1d4c93['plugin'] in _0x4f652f) {
                    _0x42f423 = _0x4f652f[_0x1d4c93['plugin']];
                    if (!isNumber(_0x42f423['total']))
                        _0x42f423['total'] = 0x1;
                    if (!isNumber(_0x42f423['success']))
                        _0x42f423['success'] = _0x1d4c93['error'] != null ? 0x0 : 0x1;
                    if (!isNumber(_0x42f423['last']))
                        _0x42f423['last'] = _0x577d8c;
                    if (!isNumber(_0x42f423['lastSuccess']))
                        _0x42f423['lastSuccess'] = _0x1d4c93['error'] != null ? 0x0 : _0x577d8c;
                } else
                    _0x42f423 = _0x4f652f[_0x1d4c93['plugin']] = {
                        'total': 0x1,
                        'success': _0x1d4c93['error'] != null ? 0x0 : 0x1,
                        'last': _0x577d8c,
                        'lastSuccess': _0x1d4c93['error'] != null ? 0x0 : _0x577d8c
                    };
                _0x42f423['total'] += 0x1;
                _0x42f423['last'] = _0x577d8c;
                if (_0x1d4c93['error'] == null) {
                    _0x42f423['success'] += 0x1;
                    _0x42f423['lastSuccess'] = _0x577d8c;
                }
            }
        }
        try {
            if (!opts['noprint'])
                await (await import('./lib/print.js'))['default'](_0x1d4c93, this);
        } catch (_0x1c626c) {
            console['log'](_0x1d4c93, _0x1d4c93['quoted'], _0x1c626c);
        }
        if (opts['autoread'])
            await this['chatRead'](_0x1d4c93['chat'], _0x1d4c93['isGroup'] ? _0x1d4c93['sender'] : undefined, _0x1d4c93['id'] || _0x1d4c93['key']['id'])['catch'](() => {
            });
    }
}
export async function participantsUpdate({
    id: _0x814054,
    participants: _0x49a827,
    action: _0x5b74ab
}) {
    if (opts['self'])
        return;
    if (this['isInit'])
        return;
    if (global['db']['data'] == null)
        await loadDatabase();
    let _0x221a85 = global['db']['data']['chats'][_0x814054] || {};
    let _0x5e4e9a = '';
    switch (_0x5b74ab) {
    case 'add':
    case 'remove':
        if (_0x221a85['welcome']) {
            let _0x27d14b = await this['groupMetadata'](_0x814054) || (conn['chats'][_0x814054] || {})['metadata'];
            for (let _0x321015 of _0x49a827) {
                let _0x1b3c09 = './src/avatar_contact.png';
                try {
                    _0x1b3c09 = await this['profilePictureUrl'](_0x321015, 'image');
                } catch (_0x56027b) {
                } finally {
                    _0x5e4e9a = (_0x5b74ab === 'add' ? (_0x221a85['sWelcome'] || this['welcome'] || conn['welcome'] || 'Welcome,\x20@user!')['replace']('@subject', await this['getName'](_0x814054))['replace']('@desc', _0x27d14b['desc']?.['toString']() || 'unknow') : _0x221a85['sBye'] || this['bye'] || conn['bye'] || 'Bye,\x20@user!')['replace']('@user', await this['getName'](_0x321015));
                    let _0x5069cc = API('zeltoria', '/api/maker/welcome', {
                        'name': await this['getName'](_0x321015),
                        'gpname': await this['getName'](_0x814054),
                        'member': _0x27d14b['participants']['length'],
                        'pp': _0x1b3c09,
                        'bg': 'https://images3.alphacoders.com/111/1111253.jpg'
                    }, 'apikey');
                    let _0x4ead3d = API('zeltoria', '/api/maker/goodbye', {
                        'name': await this['getName'](_0x321015),
                        'gpname': await this['getName'](_0x814054),
                        'member': _0x27d14b['participants']['length'],
                        'pp': _0x1b3c09,
                        'bg': 'https://images3.alphacoders.com/111/1111253.jpg'
                    }, 'apikey');
                    const _0x57a605 = {};
                    _0x57a605['mentions'] = [_0x321015];
                    this['sendFile'](_0x814054, _0x1b3c09, 'pp.jpg', _0x5e4e9a, null, ![], _0x57a605);
                }
            }
        }
        break;
    case 'promote':
        _0x5e4e9a = _0x221a85['sPromote'] || this['spromote'] || conn['spromote'] || '@user\x20```is\x20now\x20Admin```';
    case 'demote':
        if (!_0x5e4e9a)
            _0x5e4e9a = _0x221a85['sDemote'] || this['sdemote'] || conn['sdemote'] || '@user\x20```is\x20no\x20longer\x20Admin```';
        _0x5e4e9a = _0x5e4e9a['replace']('@user', '@' + _0x49a827[0x0]['split']('@')[0x0]);
        if (_0x221a85['detect'])
            this['sendMessage'](_0x814054, {
                'text': _0x5e4e9a,
                'mentions': this['parseMention'](_0x5e4e9a)
            });
        break;
    }
}
export async function groupsUpdate(_0x13c65a) {
    if (opts['self'])
        return;
    for (const _0x414556 of _0x13c65a) {
        const _0xfd631b = _0x414556['id'];
        if (!_0xfd631b)
            continue;
        let _0x531260 = global['db']['data']['chats'][_0xfd631b], _0x217ca4 = '';
        if (!_0x531260?.['detect'])
            continue;
        if (_0x414556['desc'])
            _0x217ca4 = (_0x531260['sDesc'] || this['sDesc'] || conn['sDesc'] || '```Description\x20has\x20been\x20changed\x20to```\x0a@desc')['replace']('@desc', _0x414556['desc']);
        if (_0x414556['subject'])
            _0x217ca4 = (_0x531260['sSubject'] || this['sSubject'] || conn['sSubject'] || '```Subject\x20has\x20been\x20changed\x20to```\x0a@subject')['replace']('@subject', _0x414556['subject']);
        if (_0x414556['icon'])
            _0x217ca4 = (_0x531260['sIcon'] || this['sIcon'] || conn['sIcon'] || '```Icon\x20has\x20been\x20changed\x20to```')['replace']('@icon', _0x414556['icon']);
        if (_0x414556['revoke'])
            _0x217ca4 = (_0x531260['sRevoke'] || this['sRevoke'] || conn['sRevoke'] || '```Group\x20link\x20has\x20been\x20changed\x20to```\x0a@revoke')['replace']('@revoke', _0x414556['revoke']);
        if (!_0x217ca4)
            continue;
        await this['sendMessage'](_0xfd631b, {
            'text': _0x217ca4,
            'mentions': this['parseMention'](_0x217ca4)
        });
    }
}
export async function deleteUpdate(_0x1f3449) {
    try {
        const {
            fromMe: _0x2146ab,
            id: _0x382d57,
            participant: _0x3b9a6e
        } = _0x1f3449;
        if (_0x2146ab)
            return;
        let _0x591a61 = this['serializeM'](this['loadMessage'](_0x382d57));
        if (!_0x591a61)
            return;
        let _0x571163 = global['db']['data']['chats'][_0x591a61['chat']] || {};
        if (_0x571163['delete'])
            return;
        await this['reply'](_0x591a61['chat'], ('\x0aTerdeteksi\x20@' + _0x3b9a6e['split']`@`[0x0] + '\x20telah\x20menghapus\x20pesan\x0aUntuk\x20mematikan\x20fitur\x20ini,\x20ketik\x0a*.enable\x20delete*\x0a')['trim'](), _0x591a61, { 'mentions': [_0x3b9a6e] });
        this['copyNForward'](_0x591a61['chat'], _0x591a61)['catch'](_0x2b2580 => console['log'](_0x2b2580, _0x591a61));
    } catch (_0x3622cf) {
        console['error'](_0x3622cf);
    }
}
global['dfail'] = (_0x4bd0c1, _0x4cb71a, _0x358b90) => {
    let _0x42d5cc = '@' + _0x4cb71a['sender']['replace'](/@.+/, '');
    let _0x4f87f2 = [_0x4cb71a['sender']];
    let _0x1ebcb0 = _0x358b90['getName'](_0x4cb71a['sender']);
    const _0x54ca33 = {};
    _0x54ca33['remoteJid'] = '16504228206@s.whatsapp.net';
    const _0x1930ad = {
        'fromMe': ![],
        'participant': _0x4cb71a['sender']['split']`@`[0x0] + '@s.whatsapp.net',
        ..._0x4cb71a['chat'] ? _0x54ca33 : {}
    };
    let _0x53f2c9 = {
        'key': _0x1930ad,
        'message': {
            'contactMessage': {
                'displayName': '' + _0x1ebcb0,
                'vcard': 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;a,;;;\x0aFN:' + _0x1ebcb0 + '\x0aitem1.TEL;waid=' + _0x4cb71a['sender']['split']('@')[0x0] + ':' + _0x4cb71a['sender']['split']('@')[0x0] + '\x0aitem1.X-ABLabel:Ponsel\x0aEND:VCARD'
            }
        }
    };
    const _0x353f71 = {};
    _0x353f71['rowner'] = 'Ngapain\x20Kak?,\x20Fitur\x20Ini\x20Khusus\x20Developerku';
    _0x353f71['owner'] = 'Ngapain\x20Kak?,\x20Fitur\x20Ini\x20Khusus\x20Ownerku';
    _0x353f71['mods'] = 'Fitur\x20Ini\x20Khusus\x20Moderator';
    _0x353f71['premium'] = 'Fitur\x20Ini\x20Khusus\x20Premium\x20User';
    _0x353f71['group'] = 'Fitur\x20Ini\x20Hanya\x20Bisa\x20Digunakan\x20Di\x20Grup';
    _0x353f71['botAdmin'] = 'Jadikan\x20Lia\x20Sebagai\x20Admin\x20Terlebih\x20Dahulu\x20Agar\x20Bisa\x20Menggunakan\x20Fitur\x20Ini';
    _0x353f71['restrict'] = 'Restict\x20Belum\x20Di\x20Nyalakan\x20Untuk\x20Chat\x20Ini';
    let _0x3c0496 = _0x353f71[_0x4bd0c1];
    if (_0x3c0496)
        _0x4cb71a['reply'](_0x3c0496);
    const _0x2649c1 = {};
    _0x2649c1['unreg'] = 'Hai\x20Kak,\x20Sebelum\x20Menggunakan\x20Fiturku,\x20Kamu\x20Harus\x20Daftar\x20Ke\x20Database\x20Terlebih\x20Dahulu\x0aCaranya\x20Ketik\x20.daftar\x20namakamu.umurkamu\x0aContoh\x20:\x20.daftar\x20lia.18';
    let _0x2b85fd = _0x2649c1[_0x4bd0c1];
    if (_0x2b85fd)
        _0x4cb71a['reply'](_0x2b85fd);
};
function ucapan() {
    const _0x5cb956 = _0x21dac8['tz']('Asia/Jakarta')['format']('HH');
    let _0x419c9c = 'Sudah\x20Dini\x20Hari\x20Kok\x20Belum\x20Tidur\x20Kak?\x20🥱';
    if (_0x5cb956 >= 0x4) {
        _0x419c9c = 'Pagi\x20Kak\x20🌄';
    }
    if (_0x5cb956 >= 0xa) {
        _0x419c9c = 'Selamat\x20Siang\x20Kak\x20☀️';
    }
    if (_0x5cb956 >= 0xf) {
        _0x419c9c = 'Selamat\x20Sore\x20Kak\x20🌇';
    }
    if (_0x5cb956 >= 0x12) {
        _0x419c9c = 'Malam\x20Kak\x20🌙';
    }
    return _0x419c9c;
}
function pickRandom(_0x181022) {
    return _0x181022[Math['floor'](Math['random']() * _0x181022['length'])];
}
let file = global['__filename'](import.meta['url'], !![]);
watchFile(file, async () => {
    unwatchFile(file);
    console['log'](_0x13e02f['redBright']('Update\x20\x27handler.js\x27'));
    if (global['reloadHandler'])
        console['log'](await global['reloadHandler']());
});